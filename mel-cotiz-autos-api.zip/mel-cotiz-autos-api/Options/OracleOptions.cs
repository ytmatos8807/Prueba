namespace Mel.Cotiz.Autos.Api.Options;

public class OracleOptions
{
    public const string SectionName = "Oracle";

    public string ConnectionString { get; set; } = string.Empty;
    public string StoredProcedure { get; set; } = "EM_K_API_COTIZ.p_devuelve_costos";
    public string CartaOfertaStoredProcedure { get; set; } = "em_k_cotiz_impresion_autos.p_carta_oferta";
    public string TemplateDirectory { get; set; } = string.Empty;
}
