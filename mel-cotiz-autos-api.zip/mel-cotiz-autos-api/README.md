# mel-cotiz-autos-api

API en .NET 10 que migra la logica de `CotizadorAutomovil` desde .NET Framework 4.8.

## Endpoint

- `POST /api/CotizadorAutomovil/GenerarCotizacion`
- `POST /api/Homologacion/Submodelo`

### Body de ejemplo

```json
{
  "marcaVehiculo": "TOYOTA",
  "submodeloVehiculo": "COROLLA XEI",
  "codigoAcuerdo": "1",
  "codigoModalidad": "1",
  "codigoMoneda": "1",
  "codigoFraccionamiento": "M",
  "importeInicial": "1000",
  "marcaReferido": false,
  "codigoMarca": "10",
  "codigoModelo": "20",
  "codigoSubModelo": "30",
  "anio": "2024",
  "importeCapital": "25000",
  "marca0Km": "S",
  "marcaIva": "N",
  "codigoTipoVehiculo": "AUT",
  "numeroOcupantes": "5",
  "codigoFranquicia": "0",
  "numeroCotizacion": "0",
  "error": "",
  "tipResultado": 0,
  "nomError": ""
}
```

### Homologacion de submodelo

Si `CodigoMarca`, `CodigoModelo` y `CodigoSubModelo` no vienen informados, el API intenta resolverlos con la combinacion:

- `MarcaVehiculo`
- `Anio`
- `SubmodeloVehiculo`

Si no existe homologacion o hay ambiguedad, la cotizacion retorna `Resultado=false` con observacion funcional.

Puedes probar la homologacion previa en:

- `POST /api/Homologacion/Submodelo`

## Configuracion

En `appsettings.json` configurar:

```json
"Oracle": {
  "ConnectionString": "<TU_CONNECTION_STRING>",
  "StoredProcedure": "EM_K_API_COTIZ.p_devuelve_costos",
  "CartaOfertaStoredProcedure": "em_k_cotiz_impresion_autos.p_carta_oferta",
  "TemplateDirectory": "<RUTA_PLANTILLAS_PDF>"
}
```

## Ejecutar

```bash
dotnet restore
dotnet run
```

Swagger disponible en entorno `Development`.

## Notas de migracion

- Se conserva la ruta funcional: `GenerarCotizacion`.
- Se conservan los 26 parametros del llamado legado.
- El servicio de carta oferta (`ImpresionService`) queda como punto de extension para conectar tu implementacion real.
- Se agrega `o_cursor` como parametro de salida para leer filas del procedimiento.
- `ImpresionService` ya replica el flujo legacy: obtiene `p_nombre_plantilla` y los datos de carta oferta desde Oracle.
- La generacion final del PDF depende de `IPdfTemplateRenderer` (actualmente en modo placeholder con `NullPdfTemplateRenderer`).
- La homologacion de submodelos esta en una capa dedicada (`ISubmodeloHomologacionService`) y actualmente usa repositorio en memoria como referencia inicial.
