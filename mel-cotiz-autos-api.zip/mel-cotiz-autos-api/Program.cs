using Mel.Cotiz.Autos.Api.Options;
using Mel.Cotiz.Autos.Api.Services;
using Mel.Cotiz.Autos.Api.Homologacion;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.Configure<OracleOptions>(builder.Configuration.GetSection(OracleOptions.SectionName));

builder.Services.AddScoped<ICotizadorAutomovilService, CotizadorAutomovilService>();
builder.Services.AddScoped<IOracleCotizacionRepository, OracleCotizacionRepository>();
builder.Services.AddScoped<IImpresionService, ImpresionService>();
builder.Services.AddScoped<IPdfTemplateRenderer, NullPdfTemplateRenderer>();
builder.Services.AddScoped<ISubmodeloHomologacionService, SubmodeloHomologacionService>();
builder.Services.AddScoped<ISubmodeloHomologacionRepository, InMemorySubmodeloHomologacionRepository>();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.MapControllers();

app.Run();
