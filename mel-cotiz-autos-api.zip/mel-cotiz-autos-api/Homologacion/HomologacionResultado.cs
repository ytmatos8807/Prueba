namespace Mel.Cotiz.Autos.Api.Homologacion;

public class HomologacionResultado
{
    public bool Success { get; set; }
    public string? Message { get; set; }
    public string? CodigoMarcaMapfre { get; set; }
    public string? CodigoModeloMapfre { get; set; }
    public string? CodigoSubmodeloMapfre { get; set; }
}
