namespace Mel.Cotiz.Autos.Api.Homologacion;

public class SubmodeloMapeo
{
    public string Marca { get; set; } = string.Empty;
    public int Anio { get; set; }
    public string Submodelo { get; set; } = string.Empty;
    public string CodigoMarcaMapfre { get; set; } = string.Empty;
    public string CodigoModeloMapfre { get; set; } = string.Empty;
    public string CodigoSubmodeloMapfre { get; set; } = string.Empty;
    public bool Activo { get; set; } = true;
}
