namespace Mel.Cotiz.Autos.Api.Homologacion;

public class InMemorySubmodeloHomologacionRepository : ISubmodeloHomologacionRepository
{
    private static readonly List<SubmodeloMapeo> Data =
    [
        new()
        {
            Marca = "TOYOTA",
            Anio = 2022,
            Submodelo = "COROLLA XEI",
            CodigoMarcaMapfre = "10",
            CodigoModeloMapfre = "20",
            CodigoSubmodeloMapfre = "3001",
            Activo = true
        },
        new()
        {
            Marca = "TOYOTA",
            Anio = 2023,
            Submodelo = "COROLLA XEI",
            CodigoMarcaMapfre = "10",
            CodigoModeloMapfre = "20",
            CodigoSubmodeloMapfre = "3002",
            Activo = true
        }
    ];

    public Task<IReadOnlyList<SubmodeloMapeo>> FindAsync(string marca, int anio, string submodeloNormalizado, CancellationToken cancellationToken)
    {
        var matches = Data
            .Where(x => x.Activo)
            .Where(x => string.Equals(SubmodeloNormalizer.Normalize(x.Marca), marca, StringComparison.Ordinal))
            .Where(x => x.Anio == anio)
            .Where(x => string.Equals(SubmodeloNormalizer.Normalize(x.Submodelo), submodeloNormalizado, StringComparison.Ordinal))
            .ToList();

        return Task.FromResult<IReadOnlyList<SubmodeloMapeo>>(matches);
    }
}
