using Mel.Cotiz.Autos.Api.Models;

namespace Mel.Cotiz.Autos.Api.Homologacion;

public interface ISubmodeloHomologacionService
{
    Task<HomologacionResultado> ResolverCodigosAsync(DatosDelRiesgo riesgo, CancellationToken cancellationToken);
}
