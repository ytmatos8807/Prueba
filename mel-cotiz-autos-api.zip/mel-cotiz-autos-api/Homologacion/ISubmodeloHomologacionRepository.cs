namespace Mel.Cotiz.Autos.Api.Homologacion;

public interface ISubmodeloHomologacionRepository
{
    Task<IReadOnlyList<SubmodeloMapeo>> FindAsync(string marca, int anio, string submodeloNormalizado, CancellationToken cancellationToken);
}
