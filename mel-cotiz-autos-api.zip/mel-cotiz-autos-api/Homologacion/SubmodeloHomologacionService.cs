using Mel.Cotiz.Autos.Api.Models;

namespace Mel.Cotiz.Autos.Api.Homologacion;

public class SubmodeloHomologacionService(
    ISubmodeloHomologacionRepository repository,
    ILogger<SubmodeloHomologacionService> logger) : ISubmodeloHomologacionService
{
    public async Task<HomologacionResultado> ResolverCodigosAsync(DatosDelRiesgo riesgo, CancellationToken cancellationToken)
    {
        if (!string.IsNullOrWhiteSpace(riesgo.CodigoSubModelo) &&
            !string.IsNullOrWhiteSpace(riesgo.CodigoModelo) &&
            !string.IsNullOrWhiteSpace(riesgo.CodigoMarca))
        {
            return new HomologacionResultado { Success = true };
        }

        if (string.IsNullOrWhiteSpace(riesgo.MarcaVehiculo) ||
            string.IsNullOrWhiteSpace(riesgo.SubmodeloVehiculo) ||
            string.IsNullOrWhiteSpace(riesgo.Anio))
        {
            return new HomologacionResultado
            {
                Success = false,
                Message = "Para homologar se requiere MarcaVehiculo, SubmodeloVehiculo y Anio."
            };
        }

        if (!int.TryParse(riesgo.Anio, out var anio))
        {
            return new HomologacionResultado
            {
                Success = false,
                Message = "Anio no es un valor numerico valido."
            };
        }

        var marcaNorm = SubmodeloNormalizer.Normalize(riesgo.MarcaVehiculo);
        var submodeloNorm = SubmodeloNormalizer.Normalize(riesgo.SubmodeloVehiculo);
        var matches = await repository.FindAsync(marcaNorm, anio, submodeloNorm, cancellationToken);

        if (matches.Count == 0)
        {
            return new HomologacionResultado
            {
                Success = false,
                Message = "Submodelo no homologado para la combinacion Marca-Anio-Submodelo."
            };
        }

        if (matches.Count > 1)
        {
            return new HomologacionResultado
            {
                Success = false,
                Message = "Existe mas de un submodelo homologado para la combinacion enviada."
            };
        }

        var hit = matches[0];
        logger.LogInformation("Homologacion resuelta para {Marca} {Anio} {Submodelo}: {CodigoSubmodelo}", riesgo.MarcaVehiculo, anio, riesgo.SubmodeloVehiculo, hit.CodigoSubmodeloMapfre);

        return new HomologacionResultado
        {
            Success = true,
            CodigoMarcaMapfre = hit.CodigoMarcaMapfre,
            CodigoModeloMapfre = hit.CodigoModeloMapfre,
            CodigoSubmodeloMapfre = hit.CodigoSubmodeloMapfre
        };
    }
}
