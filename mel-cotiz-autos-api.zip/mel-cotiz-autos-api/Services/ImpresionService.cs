using System.Data;
using Mel.Cotiz.Autos.Api.Options;
using Microsoft.Extensions.Options;
using Oracle.ManagedDataAccess.Client;

namespace Mel.Cotiz.Autos.Api.Services;

public class ImpresionService(
    IOptions<OracleOptions> options,
    IPdfTemplateRenderer pdfTemplateRenderer,
    ILogger<ImpresionService> logger) : IImpresionService
{
    private readonly OracleOptions _options = options.Value;

    public async Task<byte[]?> CartaOfertaAsync(long numeroCotizacion, CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(_options.ConnectionString))
        {
            logger.LogWarning("No se puede generar carta oferta: falta Oracle:ConnectionString.");
            return null;
        }

        var plantilla = await GetNombrePlantillaAsync(numeroCotizacion, cancellationToken);
        if (string.IsNullOrWhiteSpace(plantilla))
        {
            logger.LogWarning("No se recibio nombre de plantilla para cotizacion {Cotizacion}.", numeroCotizacion);
            return null;
        }

        var data = await GetDatosCartaOfertaAsync(numeroCotizacion, cancellationToken);
        var fullTemplatePath = Path.Combine(_options.TemplateDirectory, plantilla);

        return await pdfTemplateRenderer.RenderAsync(fullTemplatePath, data, cancellationToken);
    }

    private async Task<string?> GetNombrePlantillaAsync(long numeroCotizacion, CancellationToken cancellationToken)
    {
        await using var conn = new OracleConnection(_options.ConnectionString);
        await conn.OpenAsync(cancellationToken);

        await using var cmd = conn.CreateCommand();
        cmd.BindByName = true;
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.CommandText = _options.CartaOfertaStoredProcedure;

        AddIn(cmd, "p_num_cotizacion", OracleDbType.Varchar2, numeroCotizacion.ToString());
        AddIn(cmd, "p_cod_usr", OracleDbType.Varchar2, "USREMIS");
        AddIn(cmd, "p_cod_agt", OracleDbType.Varchar2, "99998");
        AddIn(cmd, "p_mca_co_franquicia", OracleDbType.Varchar2, "0");

        var plantillaOut = new OracleParameter("p_nombre_plantilla", OracleDbType.Varchar2)
        {
            Direction = ParameterDirection.Output,
            Size = 100
        };
        cmd.Parameters.Add(plantillaOut);

        var cursorOut = new OracleParameter("o_cursor", OracleDbType.RefCursor)
        {
            Direction = ParameterDirection.Output
        };
        cmd.Parameters.Add(cursorOut);

        await cmd.ExecuteNonQueryAsync(cancellationToken);

        return plantillaOut.Value == DBNull.Value ? null : plantillaOut.Value?.ToString();
    }

    private async Task<DataTable> GetDatosCartaOfertaAsync(long numeroCotizacion, CancellationToken cancellationToken)
    {
        var data = new DataTable();

        await using var conn = new OracleConnection(_options.ConnectionString);
        await conn.OpenAsync(cancellationToken);

        await using var cmd = conn.CreateCommand();
        cmd.BindByName = true;
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.CommandText = _options.CartaOfertaStoredProcedure;

        AddIn(cmd, "p_num_cotizacion", OracleDbType.Varchar2, numeroCotizacion.ToString());
        AddIn(cmd, "p_cod_usr", OracleDbType.Varchar2, "USREMIS");
        AddIn(cmd, "p_cod_agt", OracleDbType.Varchar2, "99998");
        AddIn(cmd, "p_mca_co_franquicia", OracleDbType.Varchar2, "0");

        var plantillaOut = new OracleParameter("p_nombre_plantilla", OracleDbType.Varchar2)
        {
            Direction = ParameterDirection.Output,
            Size = 100
        };
        cmd.Parameters.Add(plantillaOut);

        var cursorOut = new OracleParameter("o_cursor", OracleDbType.RefCursor)
        {
            Direction = ParameterDirection.Output
        };
        cmd.Parameters.Add(cursorOut);

        await using var reader = await cmd.ExecuteReaderAsync(CommandBehavior.CloseConnection, cancellationToken);
        data.Load(reader);

        return data;
    }

    private static void AddIn(OracleCommand cmd, string name, OracleDbType type, object? value)
    {
        var p = new OracleParameter(name, type)
        {
            Direction = ParameterDirection.Input,
            Value = value ?? DBNull.Value
        };
        cmd.Parameters.Add(p);
    }
}
