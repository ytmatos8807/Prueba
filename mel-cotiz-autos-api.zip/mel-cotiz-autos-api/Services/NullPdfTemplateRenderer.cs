using System.Data;

namespace Mel.Cotiz.Autos.Api.Services;

public class NullPdfTemplateRenderer(ILogger<NullPdfTemplateRenderer> logger) : IPdfTemplateRenderer
{
    public Task<byte[]?> RenderAsync(string templateFullPath, DataTable data, CancellationToken cancellationToken)
    {
        logger.LogWarning("No hay motor de PDF configurado. Se omitio la generación para la plantilla {TemplatePath}.", templateFullPath);
        return Task.FromResult<byte[]?>(null);
    }
}
