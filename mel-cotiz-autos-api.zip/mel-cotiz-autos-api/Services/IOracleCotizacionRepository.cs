using Mel.Cotiz.Autos.Api.Models;

namespace Mel.Cotiz.Autos.Api.Services;

public interface IOracleCotizacionRepository
{
    Task<IReadOnlyList<DatosCotizacion>> GetCotizacionesAsync(DatosDelRiesgo datosRiesgo, CancellationToken cancellationToken);
}
