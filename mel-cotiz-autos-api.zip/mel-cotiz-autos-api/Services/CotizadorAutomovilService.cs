using Mel.Cotiz.Autos.Api.Models;
using Mel.Cotiz.Autos.Api.Homologacion;

namespace Mel.Cotiz.Autos.Api.Services;

public class CotizadorAutomovilService(
    IOracleCotizacionRepository repository,
    IImpresionService impresionService,
    ISubmodeloHomologacionService homologacionService,
    ILogger<CotizadorAutomovilService> logger) : ICotizadorAutomovilService
{
    public async Task<ResultadoCotizacion> CostosAutosAsync(DatosDelRiesgo datosRiesgo, CancellationToken cancellationToken)
    {
        var resultado = new ResultadoCotizacion
        {
            Resultado = true,
            Observaciones = string.Empty
        };

        try
        {
            var homologacion = await homologacionService.ResolverCodigosAsync(datosRiesgo, cancellationToken);
            if (!homologacion.Success)
            {
                resultado.Resultado = false;
                resultado.Observaciones = homologacion.Message ?? "No se pudo homologar el submodelo.";
                return resultado;
            }

            if (!string.IsNullOrWhiteSpace(homologacion.CodigoMarcaMapfre))
            {
                datosRiesgo.CodigoMarca = homologacion.CodigoMarcaMapfre;
            }

            if (!string.IsNullOrWhiteSpace(homologacion.CodigoModeloMapfre))
            {
                datosRiesgo.CodigoModelo = homologacion.CodigoModeloMapfre;
            }

            if (!string.IsNullOrWhiteSpace(homologacion.CodigoSubmodeloMapfre))
            {
                datosRiesgo.CodigoSubModelo = homologacion.CodigoSubmodeloMapfre;
            }

            var cotizaciones = await repository.GetCotizacionesAsync(datosRiesgo, cancellationToken);

            foreach (var cotizacion in cotizaciones)
            {
                if (string.Equals(cotizacion.Mca_Carta_Oferta, "S", StringComparison.OrdinalIgnoreCase))
                {
                    cotizacion.CartaOferta = await impresionService.CartaOfertaAsync(cotizacion.Cotizacion, cancellationToken);
                }

                resultado.Cotizaciones.Add(cotizacion);
            }
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Error generando cotizacion para NumeroCotizacion={NumeroCotizacion}", datosRiesgo.NumeroCotizacion);
            resultado.Resultado = false;
            resultado.Observaciones = "Ocurrio un error al generar la cotizacion.";
        }

        return resultado;
    }
}
