using System.Data;
using Mel.Cotiz.Autos.Api.Models;
using Mel.Cotiz.Autos.Api.Options;
using Microsoft.Extensions.Options;
using Oracle.ManagedDataAccess.Client;

namespace Mel.Cotiz.Autos.Api.Services;

public class OracleCotizacionRepository(
    IOptions<OracleOptions> options,
    ILogger<OracleCotizacionRepository> logger) : IOracleCotizacionRepository
{
    private readonly OracleOptions _options = options.Value;

    public async Task<IReadOnlyList<DatosCotizacion>> GetCotizacionesAsync(DatosDelRiesgo datosRiesgo, CancellationToken cancellationToken)
    {
        if (string.IsNullOrWhiteSpace(_options.ConnectionString))
        {
            throw new InvalidOperationException("Oracle:ConnectionString no esta configurado.");
        }

        var rows = new List<DatosCotizacion>();

        await using var conn = new OracleConnection(_options.ConnectionString);
        await conn.OpenAsync(cancellationToken);

        await using var cmd = conn.CreateCommand();
        cmd.BindByName = true;
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.CommandText = _options.StoredProcedure;

        AddIn(cmd, "p_cod_acuerdo", OracleDbType.Varchar2, datosRiesgo.CodigoAcuerdo);
        AddIn(cmd, "p_cod_modalidad", OracleDbType.Varchar2, datosRiesgo.CodigoModalidad);
        AddIn(cmd, "p_cod_mon", OracleDbType.Varchar2, datosRiesgo.CodigoMoneda);
        AddIn(cmd, "p_cod_fracc_pago", OracleDbType.Varchar2, datosRiesgo.CodigoFraccionamiento);
        AddIn(cmd, "p_imp_inicial", OracleDbType.Varchar2, datosRiesgo.ImporteInicial);
        AddIn(cmd, "p_cod_usr", OracleDbType.Varchar2, "USREMIS");
        AddIn(cmd, "p_mca_cuota_igual", OracleDbType.Varchar2, "S");
        AddIn(cmd, "p_mca_referido", OracleDbType.Varchar2, "N");
        AddIn(cmd, "p_cod_agt", OracleDbType.Varchar2, "99998");
        AddIn(cmd, "p_val_cambio", OracleDbType.Varchar2, "1");
        AddIn(cmd, "p_mca_canal", OracleDbType.Varchar2, "N");
        AddIn(cmd, "p_cod_marca", OracleDbType.Varchar2, datosRiesgo.CodigoMarca);
        AddIn(cmd, "p_cod_modelo", OracleDbType.Varchar2, datosRiesgo.CodigoModelo);
        AddIn(cmd, "p_cod_sub_modelo", OracleDbType.Varchar2, datosRiesgo.CodigoSubModelo);
        AddIn(cmd, "p_anio_sub_modelo", OracleDbType.Varchar2, datosRiesgo.Anio);
        AddIn(cmd, "p_val_sub_modelo", OracleDbType.Varchar2, datosRiesgo.ImporteCapital);
        AddIn(cmd, "p_mca_0_km", OracleDbType.Varchar2, datosRiesgo.Marca0Km);
        AddIn(cmd, "p_mca_iva", OracleDbType.Varchar2, datosRiesgo.MarcaIva);
        AddIn(cmd, "p_cod_nivel_bonus_malus", OracleDbType.Varchar2, null);
        AddIn(cmd, "p_cod_tip_vehi", OracleDbType.Varchar2, datosRiesgo.CodigoTipoVehiculo);
        AddIn(cmd, "p_num_plazas", OracleDbType.Varchar2, datosRiesgo.NumeroOcupantes);
        AddIn(cmd, "p_val_franquicia", OracleDbType.Varchar2, datosRiesgo.CodigoFranquicia);
        AddIn(cmd, "p_num_cotizacion", OracleDbType.Varchar2, datosRiesgo.NumeroCotizacion);

        AddOut(cmd, "p_error", OracleDbType.Varchar2, 100);
        AddInOut(cmd, "p_tip_resultado", OracleDbType.Int32, datosRiesgo.TipResultado);
        AddOut(cmd, "p_nom_error", OracleDbType.Varchar2, 100);

        // Algunos paquetes Oracle exponen el cursor de salida de forma explicita.
        var cursor = new OracleParameter("o_cursor", OracleDbType.RefCursor)
        {
            Direction = ParameterDirection.Output
        };
        cmd.Parameters.Add(cursor);

        await using var reader = await cmd.ExecuteReaderAsync(CommandBehavior.CloseConnection, cancellationToken);

        while (await reader.ReadAsync(cancellationToken))
        {
            rows.Add(new DatosCotizacion
            {
                Cotizacion = SafeGetInt64(reader, "NUM_COTIZACION"),
                Prima = SafeGetDecimal(reader, "IMP_PRIMA"),
                Premio = SafeGetDecimal(reader, "IMP_CUOTA"),
                Observaciones = SafeGetString(reader, "NOM_DESCRIPCION"),
                Mca_Carta_Oferta = SafeGetString(reader, "MCA_CARTA_OFERTA")
            });
        }

        var pError = cmd.Parameters["p_error"].Value?.ToString();
        var pNomError = cmd.Parameters["p_nom_error"].Value?.ToString();

        if (!string.IsNullOrWhiteSpace(pError) || !string.IsNullOrWhiteSpace(pNomError))
        {
            logger.LogWarning("Stored procedure respondio con p_error={PError}, p_nom_error={PNomError}", pError, pNomError);
        }

        return rows;
    }

    private static void AddIn(OracleCommand cmd, string name, OracleDbType type, object? value)
    {
        var p = new OracleParameter(name, type)
        {
            Direction = ParameterDirection.Input,
            Value = value ?? DBNull.Value
        };

        cmd.Parameters.Add(p);
    }

    private static void AddOut(OracleCommand cmd, string name, OracleDbType type, int size)
    {
        var p = new OracleParameter(name, type)
        {
            Direction = ParameterDirection.Output,
            Size = size
        };

        cmd.Parameters.Add(p);
    }

    private static void AddInOut(OracleCommand cmd, string name, OracleDbType type, object? value)
    {
        var p = new OracleParameter(name, type)
        {
            Direction = ParameterDirection.InputOutput,
            Value = value ?? DBNull.Value
        };

        cmd.Parameters.Add(p);
    }

    private static long SafeGetInt64(OracleDataReader reader, string column)
    {
        var idx = reader.GetOrdinal(column);
        if (reader.IsDBNull(idx))
        {
            return 0;
        }

        return Convert.ToInt64(reader.GetValue(idx));
    }

    private static decimal SafeGetDecimal(OracleDataReader reader, string column)
    {
        var idx = reader.GetOrdinal(column);
        if (reader.IsDBNull(idx))
        {
            return 0m;
        }

        return Convert.ToDecimal(reader.GetValue(idx));
    }

    private static string? SafeGetString(OracleDataReader reader, string column)
    {
        var idx = reader.GetOrdinal(column);
        if (reader.IsDBNull(idx))
        {
            return null;
        }

        return reader.GetString(idx);
    }
}
