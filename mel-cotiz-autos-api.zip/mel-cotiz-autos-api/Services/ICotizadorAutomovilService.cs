using Mel.Cotiz.Autos.Api.Models;

namespace Mel.Cotiz.Autos.Api.Services;

public interface ICotizadorAutomovilService
{
    Task<ResultadoCotizacion> CostosAutosAsync(DatosDelRiesgo datosRiesgo, CancellationToken cancellationToken);
}
