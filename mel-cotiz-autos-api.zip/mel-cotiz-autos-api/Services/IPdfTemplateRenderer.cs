using System.Data;

namespace Mel.Cotiz.Autos.Api.Services;

public interface IPdfTemplateRenderer
{
    Task<byte[]?> RenderAsync(string templateFullPath, DataTable data, CancellationToken cancellationToken);
}
