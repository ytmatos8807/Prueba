namespace Mel.Cotiz.Autos.Api.Services;

public interface IImpresionService
{
    Task<byte[]?> CartaOfertaAsync(long numeroCotizacion, CancellationToken cancellationToken);
}
