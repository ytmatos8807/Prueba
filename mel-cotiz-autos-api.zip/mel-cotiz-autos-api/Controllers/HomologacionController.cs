using Mel.Cotiz.Autos.Api.Homologacion;
using Mel.Cotiz.Autos.Api.Models;
using Microsoft.AspNetCore.Mvc;

namespace Mel.Cotiz.Autos.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class HomologacionController(ISubmodeloHomologacionService homologacionService) : ControllerBase
{
    [HttpPost("Submodelo")]
    public async Task<ActionResult<HomologacionResultado>> ResolverSubmodelo([FromBody] DatosDelRiesgo request, CancellationToken cancellationToken)
    {
        var result = await homologacionService.ResolverCodigosAsync(request, cancellationToken);
        if (!result.Success)
        {
            return BadRequest(result);
        }

        return Ok(result);
    }
}
