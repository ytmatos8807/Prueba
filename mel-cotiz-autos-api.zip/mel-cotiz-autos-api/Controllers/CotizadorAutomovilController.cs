using Mel.Cotiz.Autos.Api.Models;
using Mel.Cotiz.Autos.Api.Services;
using Microsoft.AspNetCore.Mvc;

namespace Mel.Cotiz.Autos.Api.Controllers;

[ApiController]
[Route("api/[controller]")]
public class CotizadorAutomovilController(ICotizadorAutomovilService service) : ControllerBase
{
    [HttpPost("GenerarCotizacion")]
    [ProducesResponseType(typeof(ResultadoCotizacion), StatusCodes.Status200OK)]
    [ProducesResponseType(typeof(ResultadoCotizacion), StatusCodes.Status500InternalServerError)]
    public async Task<ActionResult<ResultadoCotizacion>> CostosAutos([FromBody] DatosDelRiesgo datosRiesgo, CancellationToken cancellationToken)
    {
        var result = await service.CostosAutosAsync(datosRiesgo, cancellationToken);
        return Ok(result);
    }
}
