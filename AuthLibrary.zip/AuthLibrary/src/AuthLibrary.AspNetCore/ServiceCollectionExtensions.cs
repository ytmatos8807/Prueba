using AuthLibrary.Core.Ports;
using AuthLibrary.Infrastructure;
using AuthLibrary.Persistence;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.DependencyInjection;
using AuthorizationService = AuthLibrary.Core.IAuthorizationService;

namespace AuthLibrary.AspNetCore;

/// <summary>Único punto de entrada para que cada API consuma la librería (sección 11 del análisis).</summary>
public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddAuthLibrary(this IServiceCollection services, Action<AuthLibraryOptions> configure)
    {
        var options = new AuthLibraryOptions { OracleConnectionString = string.Empty };
        configure(options);

        services.Configure<AuthLibraryPersistenceOptions>(o => o.ConnectionString = options.OracleConnectionString);
        services.Configure<AuthLibraryCacheOptions>(o => o.Ttl = options.CacheTtl);

        services.AddMemoryCache();
        services.AddHttpContextAccessor();
        services.AddSingleton(TimeProvider.System);

        services.AddScoped<IDbConnectionFactory, OracleConnectionFactory>();
        services.AddScoped<IUserAuthorizationContextRepository, OracleUserAuthorizationContextRepository>();
        services.AddScoped<IAuditRepository, OracleAuditRepository>();
        services.AddSingleton<IAuthorizationCache, MemoryAuthorizationCache>();
        services.AddScoped<AuthorizationService, AuthLibrary.Core.AuthorizationService>();
        services.AddScoped<ICurrentUserProvider, HttpContextCurrentUserProvider>();

        services.AddAuthorization();
        services.AddSingleton<IAuthorizationPolicyProvider, PermissionPolicyProvider>();
        services.AddScoped<IAuthorizationHandler, PermissionAuthorizationHandler>();

        return services;
    }
}
