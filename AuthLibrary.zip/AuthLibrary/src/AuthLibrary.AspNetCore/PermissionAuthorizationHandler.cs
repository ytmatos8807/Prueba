using Microsoft.AspNetCore.Authorization;
using AuthorizationService = AuthLibrary.Core.IAuthorizationService;

namespace AuthLibrary.AspNetCore;

/// <summary>
/// No decide 401 (eso lo resuelve el pipeline de autenticación cuando falta identidad):
/// solo evalúa el permiso vía IAuthorizationService y falla (403) si no corresponde.
/// </summary>
public sealed class PermissionAuthorizationHandler(ICurrentUserProvider currentUserProvider, AuthorizationService authorizationService)
    : AuthorizationHandler<PermissionAuthorizationRequirement>
{
    protected override async Task HandleRequirementAsync(
        AuthorizationHandlerContext context,
        PermissionAuthorizationRequirement requirement)
    {
        var userId = currentUserProvider.GetUserId();
        if (userId is null)
            return;

        if (await authorizationService.HasPermissionAsync(userId, requirement.Permission))
            context.Succeed(requirement);
    }
}
