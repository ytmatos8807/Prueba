using Microsoft.AspNetCore.Authorization;

namespace AuthLibrary.AspNetCore;

/// <summary>Uso: [RequirePermission("poliza.anular")] — sin lógica if(role==...) en el controller (sección 13).</summary>
[AttributeUsage(AttributeTargets.Method | AttributeTargets.Class, AllowMultiple = true)]
public sealed class RequirePermissionAttribute(string permission) : AuthorizeAttribute(PermissionPolicy.NameFor(permission));
