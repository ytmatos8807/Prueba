using System.Security.Claims;
using Microsoft.AspNetCore.Http;

namespace AuthLibrary.AspNetCore;

/// <summary>Abstrae la identidad autenticada; la Fase 2 (Entra ID) solo necesita reemplazar esta implementación.</summary>
public interface ICurrentUserProvider
{
    string? GetUserId();
}

public sealed class HttpContextCurrentUserProvider(IHttpContextAccessor httpContextAccessor) : ICurrentUserProvider
{
    public string? GetUserId() =>
        httpContextAccessor.HttpContext?.User?.FindFirstValue(ClaimTypes.NameIdentifier);
}
