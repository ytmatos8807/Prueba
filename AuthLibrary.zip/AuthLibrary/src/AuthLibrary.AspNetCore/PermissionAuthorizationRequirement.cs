using Microsoft.AspNetCore.Authorization;

namespace AuthLibrary.AspNetCore;

public sealed record PermissionAuthorizationRequirement(string Permission) : IAuthorizationRequirement;
