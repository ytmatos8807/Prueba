namespace AuthLibrary.AspNetCore;

public sealed class AuthLibraryOptions
{
    public required string OracleConnectionString { get; set; }

    public TimeSpan CacheTtl { get; set; } = TimeSpan.FromMinutes(5);
}
