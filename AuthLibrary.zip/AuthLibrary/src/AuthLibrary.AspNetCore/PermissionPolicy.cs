namespace AuthLibrary.AspNetCore;

internal static class PermissionPolicy
{
    private const string Prefix = "permission:";

    public static string NameFor(string permission) => Prefix + permission;

    public static string? PermissionFrom(string policyName) =>
        policyName.StartsWith(Prefix, StringComparison.Ordinal) ? policyName[Prefix.Length..] : null;
}
