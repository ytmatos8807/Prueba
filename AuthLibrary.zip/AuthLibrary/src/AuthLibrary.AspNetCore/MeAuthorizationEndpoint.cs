using AuthLibrary.Core.Ports;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;

namespace AuthLibrary.AspNetCore;

/// <summary>Respuesta con el formato JSON literal de la sección 14 del análisis.</summary>
public sealed record MeAuthorizationResponse(IReadOnlyList<MeAuthorizationRole> Roles, IReadOnlyList<string> Permissions);

public sealed record MeAuthorizationRole(string Code, IReadOnlyDictionary<string, IReadOnlyList<string>> Scopes);

public static class MeAuthorizationEndpointExtensions
{
    /// <summary>El Front usa esta respuesta para menús/botones; cada endpoint de negocio igual revalida en la API (sección 14).</summary>
    public static IEndpointRouteBuilder MapAuthLibraryMeEndpoint(this IEndpointRouteBuilder endpoints, string pattern = "/me/authorization")
    {
        endpoints.MapGet(pattern, async (
            ICurrentUserProvider currentUserProvider,
            IUserAuthorizationContextRepository contextRepository,
            CancellationToken cancellationToken) =>
        {
            var userId = currentUserProvider.GetUserId();
            if (userId is null)
                return Results.Unauthorized();

            var context = await contextRepository.GetContextAsync(userId, cancellationToken);
            if (context is null)
                return Results.Unauthorized();

            var response = new MeAuthorizationResponse(
                Roles: context.Roles.Select(r => new MeAuthorizationRole(r.Code, r.Scopes)).ToList(),
                Permissions: context.Permissions.ToList());

            return Results.Ok(response);
        }).RequireAuthorization();

        return endpoints;
    }
}
