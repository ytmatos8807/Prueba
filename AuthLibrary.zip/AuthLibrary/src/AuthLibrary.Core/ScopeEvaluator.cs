using AuthLibrary.Contracts;

namespace AuthLibrary.Core;

/// <summary>Evalúa si el scope efectivo de un usuario satisface el scope requerido por una operación.</summary>
public static class ScopeEvaluator
{
    /// <summary>
    /// Un scope requerido se satisface si el usuario tiene, para ese mismo tipo, al menos un valor
    /// en común (ANY-match) — ej. sección 10: Pedro con scopes PRODUCTO=[AUTOMOVIL,HOGAR,VIDA]
    /// satisface un requerido PRODUCTO=[HOGAR] pero no PRODUCTO=[INCENDIO].
    /// </summary>
    public static bool IsSatisfied(AuthorizationScope? required, IReadOnlyDictionary<string, IReadOnlyList<string>> userScopes)
    {
        if (required is null)
            return true;

        if (!userScopes.TryGetValue(required.Type, out var grantedValues))
            return false;

        return required.Values.Any(grantedValues.Contains);
    }
}
