using AuthLibrary.Contracts;

namespace AuthLibrary.Core.Ports;

/// <summary>Puerto hacia la persistencia: registra eventos en AUTH_AUDIT.</summary>
public interface IAuditRepository
{
    Task RecordAsync(AuditEvent auditEvent, CancellationToken cancellationToken = default);
}
