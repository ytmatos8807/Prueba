using AuthLibrary.Contracts;

namespace AuthLibrary.Core.Ports;

/// <summary>Puerto de cache del contexto de autorización (sección 15 del análisis).</summary>
public interface IAuthorizationCache
{
    Task<UserAuthorizationContext?> GetAsync(string userId, CancellationToken cancellationToken = default);

    Task SetAsync(UserAuthorizationContext context, CancellationToken cancellationToken = default);

    /// <summary>Invalida el contexto cacheado; debe llamarse ante cualquier cambio de rol/permiso/scope del usuario.</summary>
    Task InvalidateAsync(string userId, CancellationToken cancellationToken = default);
}
