using AuthLibrary.Contracts;

namespace AuthLibrary.Core.Ports;

/// <summary>Puerto hacia la persistencia: resuelve el contexto de autorización efectivo de un usuario.</summary>
public interface IUserAuthorizationContextRepository
{
    Task<UserAuthorizationContext?> GetContextAsync(string userId, CancellationToken cancellationToken = default);
}
