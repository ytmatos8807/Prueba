using AuthLibrary.Contracts;

namespace AuthLibrary.Core;

/// <summary>Contrato literal de la sección 12 del análisis de reingeniería de roles.</summary>
public interface IAuthorizationService
{
    Task<bool> HasPermissionAsync(string userId, string permission, CancellationToken cancellationToken = default);

    Task<AuthorizationResult> AuthorizeAsync(AuthorizationRequest request, CancellationToken cancellationToken = default);
}
