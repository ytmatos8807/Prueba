using AuthLibrary.Contracts;
using AuthLibrary.Core.Ports;

namespace AuthLibrary.Core;

/// <summary>
/// Orquesta el flujo de autorización de la sección 10: contexto (cache→repo) → validaciones → auditoría.
/// Sin dependencia de ASP.NET, Oracle o Entra (puertos únicamente).
/// </summary>
public sealed class AuthorizationService(
    IUserAuthorizationContextRepository contextRepository,
    IAuthorizationCache cache,
    IAuditRepository auditRepository,
    TimeProvider timeProvider) : IAuthorizationService
{
    public async Task<bool> HasPermissionAsync(string userId, string permission, CancellationToken cancellationToken = default)
    {
        var result = await AuthorizeAsync(new AuthorizationRequest(userId, permission), cancellationToken);
        return result.Allowed;
    }

    public async Task<AuthorizationResult> AuthorizeAsync(AuthorizationRequest request, CancellationToken cancellationToken = default)
    {
        var context = await GetContextAsync(request.UserId, cancellationToken);

        var result = Evaluate(context, request);

        await auditRepository.RecordAsync(
            new AuditEvent(
                Actor: request.UserId,
                Action: result.Allowed ? AuditActions.AuthorizationAllowed : AuditActions.AuthorizationDenied,
                Resource: request.ResourceType is null ? null : $"{request.ResourceType}:{request.ResourceId}",
                Permission: request.Permission,
                Scope: request.Scope is null ? null : $"{request.Scope.Type}={string.Join(',', request.Scope.Values)}",
                Result: result.Allowed,
                Timestamp: timeProvider.GetUtcNow()),
            cancellationToken);

        return result;
    }

    private static AuthorizationResult Evaluate(UserAuthorizationContext? context, AuthorizationRequest request)
    {
        if (context is null)
            return AuthorizationResult.Deny(AuthorizationResultReason.Unauthenticated);

        if (!context.IsActive)
            return AuthorizationResult.Deny(AuthorizationResultReason.UserDisabled);

        if (!context.Permissions.Contains(request.Permission))
            return AuthorizationResult.Deny(AuthorizationResultReason.PermissionDenied);

        if (!ScopeEvaluator.IsSatisfied(request.Scope, context.Scopes))
            return AuthorizationResult.Deny(AuthorizationResultReason.ScopeDenied);

        return AuthorizationResult.Allow();
    }

    private async Task<UserAuthorizationContext?> GetContextAsync(string userId, CancellationToken cancellationToken)
    {
        var cached = await cache.GetAsync(userId, cancellationToken);
        if (cached is not null)
            return cached;

        var context = await contextRepository.GetContextAsync(userId, cancellationToken);
        if (context is not null)
            await cache.SetAsync(context, cancellationToken);

        return context;
    }
}
