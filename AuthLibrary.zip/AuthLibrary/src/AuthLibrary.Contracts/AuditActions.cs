namespace AuthLibrary.Contracts;

/// <summary>Valores de auditoría literales de la sección 16 del análisis.</summary>
public static class AuditActions
{
    public const string AuthorizationAllowed = "AUTHORIZATION_ALLOWED";
    public const string AuthorizationDenied = "AUTHORIZATION_DENIED";
    public const string RoleAssigned = "ROLE_ASSIGNED";
    public const string RoleRemoved = "ROLE_REMOVED";
    public const string PermissionAddedToRole = "PERMISSION_ADDED_TO_ROLE";
    public const string PermissionRemovedFromRole = "PERMISSION_REMOVED_FROM_ROLE";
}
