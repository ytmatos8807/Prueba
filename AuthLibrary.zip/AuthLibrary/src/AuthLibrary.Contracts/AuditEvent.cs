namespace AuthLibrary.Contracts;

/// <summary>Fila a persistir en AUTH_AUDIT (sección 16 del análisis).</summary>
public sealed record AuditEvent(
    string Actor,
    string Action,
    string? Resource,
    string Permission,
    string? Scope,
    bool Result,
    DateTimeOffset Timestamp);
