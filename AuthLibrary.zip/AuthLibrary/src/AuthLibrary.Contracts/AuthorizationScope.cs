namespace AuthLibrary.Contracts;

/// <summary>Ámbito requerido para una operación: tipo de scope (PRODUCTO, SUCURSAL, etc.) y valores aceptados.</summary>
public sealed record AuthorizationScope(string Type, IReadOnlyList<string> Values);
