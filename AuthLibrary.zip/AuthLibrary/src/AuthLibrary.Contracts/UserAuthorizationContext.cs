namespace AuthLibrary.Contracts;

/// <summary>Contexto de autorización ya resuelto de un usuario: roles, permisos y scopes activos.</summary>
public sealed record UserAuthorizationContext(
    string UserId,
    bool IsActive,
    IReadOnlyList<RoleInfo> Roles,
    IReadOnlySet<string> Permissions,
    IReadOnlyDictionary<string, IReadOnlyList<string>> Scopes);
