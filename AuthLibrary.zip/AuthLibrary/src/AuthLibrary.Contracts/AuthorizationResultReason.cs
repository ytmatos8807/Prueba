namespace AuthLibrary.Contracts;

/// <summary>
/// Motivo de un resultado de autorización. Rol/permiso deshabilitados no tienen un valor propio:
/// el repositorio ya los excluye del contexto efectivo, por lo que ambos casos se observan como PermissionDenied.
/// </summary>
public enum AuthorizationResultReason
{
    Allowed,
    Unauthenticated,
    UserDisabled,
    PermissionDenied,
    ScopeDenied
}
