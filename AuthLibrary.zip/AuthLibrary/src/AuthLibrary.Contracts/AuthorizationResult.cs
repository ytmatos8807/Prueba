namespace AuthLibrary.Contracts;

public sealed record AuthorizationResult(bool Allowed, AuthorizationResultReason Reason)
{
    public static AuthorizationResult Allow() => new(true, AuthorizationResultReason.Allowed);

    public static AuthorizationResult Deny(AuthorizationResultReason reason)
    {
        if (reason == AuthorizationResultReason.Allowed)
            throw new ArgumentException("Un resultado denegado no puede usar el motivo Allowed.", nameof(reason));

        return new AuthorizationResult(false, reason);
    }
}
