namespace AuthLibrary.Contracts;

/// <summary>Contrato literal de la sección 12 del análisis de reingeniería de roles.</summary>
public sealed record AuthorizationRequest(
    string UserId,
    string Permission,
    AuthorizationScope? Scope = null,
    string? ResourceType = null,
    string? ResourceId = null);
