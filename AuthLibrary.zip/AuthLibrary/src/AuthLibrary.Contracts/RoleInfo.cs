namespace AuthLibrary.Contracts;

/// <summary>Scopes en <paramref name="Scopes"/> son los propios de esta asignación de rol (AUTH_USER_ROLE_SCOPE).</summary>
public sealed record RoleInfo(string Code, string Name, bool Active, IReadOnlyDictionary<string, IReadOnlyList<string>> Scopes);
