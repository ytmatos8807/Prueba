using AuthLibrary.Contracts;
using AuthLibrary.Core.Ports;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Options;

namespace AuthLibrary.Infrastructure;

/// <summary>Cache en proceso del contexto de autorización. Para múltiples instancias de API, reemplazar por Redis.</summary>
public sealed class MemoryAuthorizationCache(IMemoryCache memoryCache, IOptions<AuthLibraryCacheOptions> options)
    : IAuthorizationCache
{
    private static string CacheKey(string userId) => $"auth:user:{userId}";

    public Task<UserAuthorizationContext?> GetAsync(string userId, CancellationToken cancellationToken = default)
    {
        memoryCache.TryGetValue<UserAuthorizationContext>(CacheKey(userId), out var context);
        return Task.FromResult(context);
    }

    public Task SetAsync(UserAuthorizationContext context, CancellationToken cancellationToken = default)
    {
        memoryCache.Set(CacheKey(context.UserId), context, options.Value.Ttl);
        return Task.CompletedTask;
    }

    public Task InvalidateAsync(string userId, CancellationToken cancellationToken = default)
    {
        memoryCache.Remove(CacheKey(userId));
        return Task.CompletedTask;
    }
}
