namespace AuthLibrary.Infrastructure;

/// <summary>TTL del contexto de autorización cacheado (sección 15 del análisis, default 5 minutos).</summary>
public sealed class AuthLibraryCacheOptions
{
    public TimeSpan Ttl { get; set; } = TimeSpan.FromMinutes(5);
}
