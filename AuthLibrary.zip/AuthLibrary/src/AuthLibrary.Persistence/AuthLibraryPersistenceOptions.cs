namespace AuthLibrary.Persistence;

/// <summary>Configuración de conexión a la base de datos Oracle que aloja las tablas AUTH_*.</summary>
public sealed class AuthLibraryPersistenceOptions
{
    public required string ConnectionString { get; set; }
}
