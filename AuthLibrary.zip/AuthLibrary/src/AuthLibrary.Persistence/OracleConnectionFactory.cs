using System.Data;
using Microsoft.Extensions.Options;
using Oracle.ManagedDataAccess.Client;

namespace AuthLibrary.Persistence;

public interface IDbConnectionFactory
{
    IDbConnection CreateConnection();
}

public sealed class OracleConnectionFactory(IOptions<AuthLibraryPersistenceOptions> options) : IDbConnectionFactory
{
    public IDbConnection CreateConnection() => new OracleConnection(options.Value.ConnectionString);
}
