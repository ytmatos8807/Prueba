using AuthLibrary.Contracts;
using AuthLibrary.Core.Ports;
using Dapper;

namespace AuthLibrary.Persistence;

public sealed class OracleAuditRepository(IDbConnectionFactory connectionFactory) : IAuditRepository
{
    private const string InsertSql = """
        INSERT INTO AUTH_AUDIT (ACTOR, ACTION, RESOURCE, PERMISSION, SCOPE, RESULT, CREATED_AT)
        VALUES (:Actor, :Action, :Resource, :Permission, :Scope, :Result, :CreatedAt)
        """;

    public async Task RecordAsync(AuditEvent auditEvent, CancellationToken cancellationToken = default)
    {
        using var connection = connectionFactory.CreateConnection();

        await connection.ExecuteAsync(new CommandDefinition(
            InsertSql,
            new
            {
                auditEvent.Actor,
                auditEvent.Action,
                auditEvent.Resource,
                auditEvent.Permission,
                auditEvent.Scope,
                Result = auditEvent.Result ? "Y" : "N",
                CreatedAt = auditEvent.Timestamp.UtcDateTime
            },
            cancellationToken: cancellationToken));
    }
}
