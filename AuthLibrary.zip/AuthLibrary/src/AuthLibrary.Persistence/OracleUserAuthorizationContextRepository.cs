using AuthLibrary.Contracts;
using AuthLibrary.Core.Ports;
using Dapper;

namespace AuthLibrary.Persistence;

/// <summary>
/// Resuelve el contexto de autorización efectivo desde AUTH_*.
/// Nota Oracle/Dapper: cada parámetro nombrado se usa una única vez por consulta —
/// ODP.NET con BindByName=false liga por posición, y un mismo nombre repetido rompería el binding.
/// </summary>
public sealed class OracleUserAuthorizationContextRepository(IDbConnectionFactory connectionFactory)
    : IUserAuthorizationContextRepository
{
    private const string SelectUserSql = """
        SELECT ID, EXTERNAL_ID, ACTIVE
        FROM AUTH_USER
        WHERE EXTERNAL_ID = :ExternalId
        """;

    private const string SelectRolesSql = """
        SELECT r.ID, r.CODE, r.NAME, r.ACTIVE
        FROM AUTH_USER_ROLE ur
        JOIN AUTH_ROLE r ON r.ID = ur.ROLE_ID
        WHERE ur.USER_ID = :UserId
          AND ur.ACTIVE = 'Y'
          AND r.ACTIVE = 'Y'
          AND (ur.VALID_FROM IS NULL OR ur.VALID_FROM <= SYSTIMESTAMP)
          AND (ur.VALID_TO IS NULL OR ur.VALID_TO >= SYSTIMESTAMP)
        """;

    private const string SelectPermissionsSql = """
        SELECT DISTINCT p.CODE
        FROM AUTH_USER_ROLE ur
        JOIN AUTH_ROLE r ON r.ID = ur.ROLE_ID
        JOIN AUTH_ROLE_PERMISSION rp ON rp.ROLE_ID = r.ID
        JOIN AUTH_PERMISSION p ON p.ID = rp.PERMISSION_ID
        WHERE ur.USER_ID = :UserId
          AND ur.ACTIVE = 'Y'
          AND r.ACTIVE = 'Y'
          AND p.ACTIVE = 'Y'
          AND (ur.VALID_FROM IS NULL OR ur.VALID_FROM <= SYSTIMESTAMP)
          AND (ur.VALID_TO IS NULL OR ur.VALID_TO >= SYSTIMESTAMP)
        """;

    // AUTH_USER_ROLE_SCOPE cuelga de una asignación de rol puntual (USER_ROLE_ID), no del usuario en general.
    private const string SelectScopesSql = """
        SELECT r.ID AS RoleId, st.CODE AS ScopeType, urs.SCOPE_VALUE AS ScopeValue
        FROM AUTH_USER_ROLE ur
        JOIN AUTH_ROLE r ON r.ID = ur.ROLE_ID
        JOIN AUTH_USER_ROLE_SCOPE urs ON urs.USER_ROLE_ID = ur.ID
        JOIN AUTH_SCOPE_TYPE st ON st.ID = urs.SCOPE_TYPE_ID
        WHERE ur.USER_ID = :UserId
          AND ur.ACTIVE = 'Y'
        """;

    public async Task<UserAuthorizationContext?> GetContextAsync(string userId, CancellationToken cancellationToken = default)
    {
        using var connection = connectionFactory.CreateConnection();

        var user = await connection.QuerySingleOrDefaultAsync<(decimal Id, string ExternalId, string Active)>(
            new CommandDefinition(SelectUserSql, new { ExternalId = userId }, cancellationToken: cancellationToken));

        if (user.ExternalId is null)
            return null;

        var roleRows = (await connection.QueryAsync<(decimal Id, string Code, string Name, string Active)>(
                new CommandDefinition(SelectRolesSql, new { UserId = user.Id }, cancellationToken: cancellationToken)))
            .ToList();

        var permissions = (await connection.QueryAsync<string>(
                new CommandDefinition(SelectPermissionsSql, new { UserId = user.Id }, cancellationToken: cancellationToken)))
            .ToHashSet();

        var scopeRows = (await connection.QueryAsync<(decimal RoleId, string ScopeType, string ScopeValue)>(
                new CommandDefinition(SelectScopesSql, new { UserId = user.Id }, cancellationToken: cancellationToken)))
            .ToList();

        var scopesByRole = scopeRows
            .GroupBy(row => row.RoleId)
            .ToDictionary(
                group => group.Key,
                group => BuildScopeDictionary(group.Select(row => (row.ScopeType, row.ScopeValue))));

        var roles = roleRows
            .Select(r => new RoleInfo(
                r.Code,
                r.Name,
                r.Active == "Y",
                scopesByRole.TryGetValue(r.Id, out var roleScopes) ? roleScopes : new Dictionary<string, IReadOnlyList<string>>()))
            .ToList();

        // Unión de scopes entre todos los roles activos: alcanza con que UN rol otorgue el scope para satisfacerlo.
        var scopes = BuildScopeDictionary(scopeRows.Select(row => (row.ScopeType, row.ScopeValue)));

        return new UserAuthorizationContext(
            UserId: user.ExternalId,
            IsActive: user.Active == "Y",
            Roles: roles,
            Permissions: permissions,
            Scopes: scopes);
    }

    private static Dictionary<string, IReadOnlyList<string>> BuildScopeDictionary(IEnumerable<(string ScopeType, string ScopeValue)> rows) =>
        rows
            .GroupBy(row => row.ScopeType)
            .ToDictionary(
                group => group.Key,
                group => (IReadOnlyList<string>)group.Select(row => row.ScopeValue).Distinct().ToList());
}
