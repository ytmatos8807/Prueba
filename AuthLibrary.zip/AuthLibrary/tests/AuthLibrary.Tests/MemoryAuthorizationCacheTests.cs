using AuthLibrary.Contracts;
using AuthLibrary.Infrastructure;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Options;
using Xunit;

namespace AuthLibrary.Tests;

public class MemoryAuthorizationCacheTests
{
    private static readonly UserAuthorizationContext Context = new(
        UserId: "pedro",
        IsActive: true,
        Roles: [],
        Permissions: new HashSet<string> { "poliza.anular" },
        Scopes: new Dictionary<string, IReadOnlyList<string>>());

    private static MemoryAuthorizationCache CreateCache() =>
        new(new MemoryCache(new MemoryCacheOptions()), Options.Create(new AuthLibraryCacheOptions()));

    [Fact]
    public async Task SetLuegoGet_DevuelveElMismoContexto()
    {
        var cache = CreateCache();

        await cache.SetAsync(Context);
        var cached = await cache.GetAsync("pedro");

        Assert.Equal(Context, cached);
    }

    [Fact]
    public async Task CambioDeRol_InvalidarLimpiaElCache()
    {
        var cache = CreateCache();
        await cache.SetAsync(Context);

        await cache.InvalidateAsync("pedro");
        var cached = await cache.GetAsync("pedro");

        Assert.Null(cached);
    }
}
