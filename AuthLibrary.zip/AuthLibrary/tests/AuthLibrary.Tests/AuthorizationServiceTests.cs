using AuthLibrary.Contracts;
using AuthLibrary.Core;
using AuthLibrary.Core.Ports;
using Moq;
using Xunit;

namespace AuthLibrary.Tests;

public class AuthorizationServiceTests
{
    private static readonly AuthorizationRequest PolizaAnular = new("pedro", "poliza.anular");

    private readonly Mock<IUserAuthorizationContextRepository> _contextRepository = new();
    private readonly Mock<IAuthorizationCache> _cache = new();
    private readonly Mock<IAuditRepository> _auditRepository = new();
    private readonly AuthorizationService _service;

    public AuthorizationServiceTests()
    {
        _cache.Setup(c => c.GetAsync(It.IsAny<string>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync((UserAuthorizationContext?)null);

        _service = new AuthorizationService(_contextRepository.Object, _cache.Object, _auditRepository.Object, TimeProvider.System);
    }

    private static UserAuthorizationContext ActiveUserWithPermissions(
        bool isActive,
        IEnumerable<string> permissions,
        IReadOnlyDictionary<string, IReadOnlyList<string>>? scopes = null) =>
        new(
            UserId: "pedro",
            IsActive: isActive,
            Roles: [],
            Permissions: permissions.ToHashSet(),
            Scopes: scopes ?? new Dictionary<string, IReadOnlyList<string>>());

    private void GivenContext(UserAuthorizationContext? context) =>
        _contextRepository
            .Setup(r => r.GetContextAsync("pedro", It.IsAny<CancellationToken>()))
            .ReturnsAsync(context);

    [Fact]
    public async Task NoAutenticado_RetornaUnauthenticated()
    {
        GivenContext(null);

        var result = await _service.AuthorizeAsync(PolizaAnular);

        Assert.False(result.Allowed);
        Assert.Equal(AuthorizationResultReason.Unauthenticated, result.Reason);
    }

    [Fact]
    public async Task UsuarioDeshabilitado_RetornaUserDisabled()
    {
        GivenContext(ActiveUserWithPermissions(isActive: false, permissions: ["poliza.anular"]));

        var result = await _service.AuthorizeAsync(PolizaAnular);

        Assert.False(result.Allowed);
        Assert.Equal(AuthorizationResultReason.UserDisabled, result.Reason);
    }

    [Fact]
    public async Task UsuarioSinPermiso_RetornaPermissionDenied()
    {
        GivenContext(ActiveUserWithPermissions(isActive: true, permissions: ["poliza.consultar"]));

        var result = await _service.AuthorizeAsync(PolizaAnular);

        Assert.False(result.Allowed);
        Assert.Equal(AuthorizationResultReason.PermissionDenied, result.Reason);
    }

    [Fact]
    public async Task UsuarioConPermiso_RetornaAllowed()
    {
        GivenContext(ActiveUserWithPermissions(isActive: true, permissions: ["poliza.anular"]));

        var result = await _service.AuthorizeAsync(PolizaAnular);

        Assert.True(result.Allowed);
        Assert.Equal(AuthorizationResultReason.Allowed, result.Reason);
    }

    [Fact]
    public async Task RolDeshabilitado_RepositorioYaLoExcluye_RetornaPermissionDenied()
    {
        // El repositorio filtra roles inactivos en el WHERE — acá se simula esa exclusión.
        GivenContext(ActiveUserWithPermissions(isActive: true, permissions: []));

        var result = await _service.AuthorizeAsync(PolizaAnular);

        Assert.False(result.Allowed);
        Assert.Equal(AuthorizationResultReason.PermissionDenied, result.Reason);
    }

    [Fact]
    public async Task PermisoDeshabilitado_RepositorioYaLoExcluye_RetornaPermissionDenied()
    {
        // El repositorio filtra AUTH_PERMISSION.ACTIVE='N' en el WHERE — acá se simula esa exclusión.
        GivenContext(ActiveUserWithPermissions(isActive: true, permissions: []));

        var result = await _service.AuthorizeAsync(PolizaAnular);

        Assert.False(result.Allowed);
        Assert.Equal(AuthorizationResultReason.PermissionDenied, result.Reason);
    }

    [Fact]
    public async Task ScopeCorrecto_RetornaAllowed()
    {
        var scopes = new Dictionary<string, IReadOnlyList<string>> { ["PRODUCTO"] = ["AUTOMOVIL", "HOGAR", "VIDA"] };
        GivenContext(ActiveUserWithPermissions(isActive: true, permissions: ["cotizacion.modificar"], scopes: scopes));

        var request = new AuthorizationRequest("pedro", "cotizacion.modificar", new AuthorizationScope("PRODUCTO", ["HOGAR"]));
        var result = await _service.AuthorizeAsync(request);

        Assert.True(result.Allowed);
    }

    [Fact]
    public async Task ScopeIncorrecto_RetornaScopeDenied()
    {
        var scopes = new Dictionary<string, IReadOnlyList<string>> { ["PRODUCTO"] = ["AUTOMOVIL", "HOGAR", "VIDA"] };
        GivenContext(ActiveUserWithPermissions(isActive: true, permissions: ["cotizacion.modificar"], scopes: scopes));

        var request = new AuthorizationRequest("pedro", "cotizacion.modificar", new AuthorizationScope("PRODUCTO", ["INCENDIO"]));
        var result = await _service.AuthorizeAsync(request);

        Assert.False(result.Allowed);
        Assert.Equal(AuthorizationResultReason.ScopeDenied, result.Reason);
    }

    [Fact]
    public async Task SiempreRegistraAuditoria()
    {
        GivenContext(ActiveUserWithPermissions(isActive: true, permissions: ["poliza.anular"]));

        await _service.AuthorizeAsync(PolizaAnular);

        _auditRepository.Verify(
            a => a.RecordAsync(It.Is<AuditEvent>(e => e.Action == AuditActions.AuthorizationAllowed), It.IsAny<CancellationToken>()),
            Times.Once);
    }
}
