using AuthLibrary.Contracts;
using AuthLibrary.Core;
using Xunit;

namespace AuthLibrary.Tests;

public class ScopeEvaluatorTests
{
    private static readonly IReadOnlyDictionary<string, IReadOnlyList<string>> PedroScopes =
        new Dictionary<string, IReadOnlyList<string>> { ["PRODUCTO"] = ["AUTOMOVIL", "HOGAR", "VIDA"] };

    [Fact]
    public void SinScopeRequerido_SiempreSatisfecho()
    {
        Assert.True(ScopeEvaluator.IsSatisfied(null, PedroScopes));
    }

    [Fact]
    public void ValorEnComun_Satisfecho()
    {
        var required = new AuthorizationScope("PRODUCTO", ["HOGAR"]);
        Assert.True(ScopeEvaluator.IsSatisfied(required, PedroScopes));
    }

    [Fact]
    public void SinValorEnComun_NoSatisfecho()
    {
        var required = new AuthorizationScope("PRODUCTO", ["INCENDIO"]);
        Assert.False(ScopeEvaluator.IsSatisfied(required, PedroScopes));
    }

    [Fact]
    public void TipoDeScopeNoAsignado_NoSatisfecho()
    {
        var required = new AuthorizationScope("SUCURSAL", ["CENTRAL"]);
        Assert.False(ScopeEvaluator.IsSatisfied(required, PedroScopes));
    }

    [Fact]
    public void AlMenosUnValorEnComun_ANYMatch_Satisfecho()
    {
        var required = new AuthorizationScope("PRODUCTO", ["INCENDIO", "VIDA"]);
        Assert.True(ScopeEvaluator.IsSatisfied(required, PedroScopes));
    }
}
